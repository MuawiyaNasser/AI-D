import React, { createContext, useContext, useState } from 'react';
import { ChatContextType, Difficulty, Message } from '../types';

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: 'Hello! I am AI-D, your first aid assistant. How can I help you today?',
      sender: 'ai',
      timestamp: new Date(),
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);

  const sendMessage = (content: string, difficulty: Difficulty) => {
    if (!content.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      sender: 'user',
      timestamp: new Date(),
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);

    // Simulate AI response based on difficulty
    setTimeout(() => {
      let response = '';
      
      switch (difficulty) {
        case 'easy':
          response = `Here's a simplified explanation: ${content} is a common first aid scenario. The key steps are: 1) Assess the situation, 2) Ensure safety, 3) Call for help if needed, 4) Provide basic care using simple techniques.`;
          break;
        case 'medium':
          response = `Regarding ${content}: This requires a methodical approach. First, assess vital signs including consciousness, breathing, and circulation. Then implement the appropriate protocol based on your findings. Remember to document all interventions and reassess regularly.`;
          break;
        case 'critical':
          response = `For critical situations involving ${content}: Immediate action is required. Assess: Airway, Breathing, Circulation. Implement emergency protocols including positioning, potential CPR, hemorrhage control, and shock management. Detailed vital sign monitoring is essential. Call emergency services immediately. Document: time of incident, vital signs, interventions, and response to treatment.`;
          break;
        default:
          response = `I understand you're asking about ${content}. Let me help you with that...`;
      }

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: response,
        sender: 'ai',
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, aiMessage]);
      setIsLoading(false);
    }, 1500);
  };

  const clearChat = () => {
    setMessages([
      {
        id: '1',
        content: 'Hello! I am AI-D, your first aid assistant. How can I help you today?',
        sender: 'ai',
        timestamp: new Date(),
      },
    ]);
  };

  return (
    <ChatContext.Provider value={{ messages, sendMessage, clearChat, isLoading }}>
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = (): ChatContextType => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};